<html>
<body>

<div>
<a href="/index">index</a>
<a href="/about">about</a>
<a href="/service">service</a>
@yield('content')
</div>
</body>
</html>