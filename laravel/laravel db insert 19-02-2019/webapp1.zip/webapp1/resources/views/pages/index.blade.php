@extends('layouts.app1')
@section('content')
<!-- <a href="/index">index</a>
<a href="/about">about</a>
<a href="/service">service</a> -->
<h1>index</h1>
<h2>{{$title}}</h2>
<p>welcome to ooty nice to meet you</p>
@endsection