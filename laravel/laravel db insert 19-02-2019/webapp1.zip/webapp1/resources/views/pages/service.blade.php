@extends('layouts.app1')
@section('content')
<!-- <a href="/index">index</a>
<a href="/about">about</a>
<a href="/service">service</a> -->
<h1>service</h1>
<p>welcome toyou</p>
@endsection