@extends('layouts.app1')
@section('content')
<!-- <a href="/index">index</a>
<a href="/about">about</a>
<a href="/service">service</a> -->x
<h1>index</h1>
<h2>{{$name}}</h2>
<p>welcome to </p>
@endsection