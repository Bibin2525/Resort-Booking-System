<html>
<body>
</body>
<div>
<a href="/index">index</a>
<a href="/about">about</a>
<a href="/service">service</a>
<?php echo $__env->yieldContent('content'); ?>
</div>
</html>