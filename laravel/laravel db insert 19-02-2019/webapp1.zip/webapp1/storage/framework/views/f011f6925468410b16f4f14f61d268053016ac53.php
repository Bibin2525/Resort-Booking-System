<?php $__env->startSection('content'); ?>
<!-- <a href="/index">index</a>
<a href="/about">about</a>
<a href="/service">service</a> -->x
<h1>index</h1>
<h2><?php echo e($name); ?></h2>
<p>welcome to </p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app1', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>