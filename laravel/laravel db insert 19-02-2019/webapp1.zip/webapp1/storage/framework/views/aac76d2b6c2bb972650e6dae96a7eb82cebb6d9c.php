<form method="post" action="<?php echo e(route('books.store')); ?>">
<?php echo csrf_field(); ?>
title <input type="text" name="title"> <br/>
body<input type="text" name="body"><br/>
<button type="submit">add<button>
</form>
</html>

