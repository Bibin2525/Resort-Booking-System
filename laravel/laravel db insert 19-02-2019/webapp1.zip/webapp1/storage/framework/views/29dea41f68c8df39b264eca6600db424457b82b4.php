<form method="post" action="<?php echo e(route(books.store)); ?>">
title <input type="text" name="title"> <br/>
<body>
body<input type="text" name="body"><br/>
<button type="submit">add<button>
</form>
</body>
</html>

